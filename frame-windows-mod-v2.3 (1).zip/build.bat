@echo off
where geode >nul 2>nul || (echo [!] Geode CLI not found. Install from https://github.com/geode-sdk/cli/releases & exit /b 1)
if "%GEODE_SDK%"=="" (geode sdk install nightly --ready && geode sdk setup)
geode build
