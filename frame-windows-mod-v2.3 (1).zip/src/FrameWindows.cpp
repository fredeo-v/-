// Frame Windows v2.3 — drag & drop HUD edition
// Модуль: кружки кликов/отжатий (стиль FB frame counter), статичный HUD
// (FPS фрейм-перфекта + мс окна) слева снизу, счётчик окон слева сверху.
// НОВОЕ В 2.3: любой HUD-элемент можно перетащить мышью/пальцем и позиция
// сохраняется в конфиг. Режим перетаскивания — клавиша из настройки
// hud-drag-key (по умолчанию F9); в этом режиме элементы подсвечиваются
// рамкой, клики в игре не проходят.

#include <Geode/Geode.hpp>
#include <Geode/modify/PlayerObject.hpp>
#include <Geode/modify/PlayLayer.hpp>
#include <Geode/modify/CCDirector.hpp>
#include <Geode/binding/PlayLayer.hpp>
#include <Geode/binding/PlayerObject.hpp>
#include <Geode/utils/cocos.hpp>
#include <img/img_cache.h>

using namespace geode::prelude;

// ---------------------------------------------------------------------------
// Конфиг позиций HUD: сохраняется как json в настройках мода.
// Формат: {"counter": {"x": 0.02, "y": 0.86}, "status": {"x": 0.02, "y": 0.06}}
// Координаты — в долях экрана (0..1), чтобы позиция не ломалась при смене
// разрешения. Якорь — левый верхний угол элемента.
// ---------------------------------------------------------------------------
struct HudPos { float x = 0.02f; float y = 0.86f; };

static nlohmann::json s_hudJson = {
    {"counter", {{"x", 0.02}, {"y", 0.86}}},
    {"status",  {{"x", 0.02}, {"y", 0.06}}}
};

static void loadHudJson() {
    auto saved = Mod::get()->getSettingValue<std::string>("hud-positions");
    if (saved && !saved->empty()) {
        auto parsed = geode::utils::file::readJson(saved.value());
        if (parsed.is_object()) s_hudJson = parsed;
    }
}
static void saveHudJson() {
    Mod::get()->setSettingValue<std::string>("hud-positions", s_hudJson.dump());
}

static HudPos getPos(const char* key) {
    HudPos p;
    if (s_hudJson.contains(key) && s_hudJson[key].is_object()) {
        if (s_hudJson[key].contains("x")) p.x = s_hudJson[key]["x"].get<float>();
        if (s_hudJson[key].contains("y")) p.y = s_hudJson[key]["y"].get<float>();
    }
    return p;
}
static void setPos(const char* key, float fx, float fy) {
    s_hudJson[key] = {{"x", fx}, {"y", fy}};
    saveHudJson();
}

// ---------------------------------------------------------------------------
// Состояние сессии: окна, счётчики, замеры
// ---------------------------------------------------------------------------
struct FrameWindowsState {
    bool dragMode = false;          // режим перетаскивания HUD
    bool visible = true;            // общий тумблер (TAB)

    // статичный HUD (левый нижний угол по умолчанию)
    float lastPerfectFps = 0.f;     // FPS, при котором клик был бы фрейм-перфектом
    float lastMsWindow  = 0.f;      // длительность окна в мс
    bool  hudHasValue = false;

    // счётчик окон
    std::map<int, int> windowBuckets;   // сегмент промежутка -> счёт
    int totalClicks = 0;

    // плюсы: доп. клики в текущем кадре (только нажатия)
    int pressesThisFrame = 0;
};
static FrameWindowsState g_state;

// Промежутки счётчика по умолчанию; пользователь меняет их в конфиге.
static std::vector<std::pair<float,float>> s_buckets = {
    {0.5f, 1.5f}, {1.5f, 3.0f}, {3.0f, 6.0f}, {6.0f, 1e9f}
};

static ccColor3B colorFor(float frames) {
    float yellow = Mod::get()->getSettingValue<double>("yellow-threshold");
    float green  = Mod::get()->getSettingValue<double>("green-threshold");
    if (frames <= 0.f) return {255, 40, 40};          // красный 0
    if (frames < yellow) return {255, 200, 40};       // жёлтый
    if (frames < green)  return {120, 220, 60};       // зелёный? нет — ниже зелёного
    return {60, 255, 90};                             // зелёный
}
// примечание: colorFor ниже yellow = жёлтый, ниже порога узости = красный
// (порог красного = минимально возможное окно, поэтому нули отдельно).

// ---------------------------------------------------------------------------
// HUD-элементы. Каждый наследует DragLayer: знает свой ключ в конфиге,
// умеет перетаскиваться в dragMode и сохранять позицию.
// ---------------------------------------------------------------------------
class DragLayer : public cocos2d::CCLayer {
protected:
    std::string m_key;
    bool m_touchActive = false;
    cocos2d::CCPoint m_touchStart, m_posStart;
    cocos2d::CCNode* m_frame = nullptr; // подсветка рамкой в dragMode
public:
    DragLayer(const char* key) : m_key(key) {}

    void setupFrame(const cocos2d::CCSize& size) {
        if (m_frame) return;
        auto rect = cocos2d::CCLayerColor::create(
            cocos2d::ccc4(80, 160, 255, 40), size.width, size.height);
        auto border = cocos2d::CCLayerColor::create(
            cocos2d::ccc4(80, 160, 255, 160), size.width, size.height);
        border->setOpacity(0);
        rect->addChild(border);
        rect->setZOrder(-1);
        this->addChild(rect);
        m_frame = rect;
        this->schedule(schedule_selector(DragLayer::tickFrame));
    }

    void tickFrame(float) {
        if (!m_frame) return;
        bool want = g_state.dragMode;
        auto border = static_cast<cocos2d::CCLayerColor*>(m_frame->getChildren().at(0));
        border->setOpacity(want ? 160 : 0);
        m_frame->setVisible(true);
    }

    bool ccTouchBegan(cocos2d::CCTouch* t, cocos2d::CCEvent*) override {
        if (!g_state.dragMode || !g_state.visible) return false;
        auto loc = this->convertToNodeSpace(t->getLocation());
        if (loc.x < 0 || loc.y < 0 ||
            loc.x > this->getContentSize().width || loc.y > this->getContentSize().height)
            return false;
        m_touchActive = true;
        m_touchStart = t->getLocation();
        m_posStart = this->getPosition();
        return true;
    }
    void ccTouchMoved(cocos2d::CCTouch* t, cocos2d::CCEvent*) override {
        if (!m_touchActive) return;
        auto win = cocos2d::CCDirector::sharedDirector()->getWinSize();
        auto d = t->getLocation() - m_touchStart;
        auto p = m_posStart + d;
        p.x = std::clamp(p.x, 0.f, win.width);
        p.y = std::clamp(p.y, 0.f, win.height);
        this->setPosition(p);
    }
    void ccTouchEnded(cocos2d::CCTouch* t, cocos2d::CCEvent*) override {
        if (!m_touchActive) return;
        m_touchActive = false;
        auto win = cocos2d::CCDirector::sharedDirector()->getWinSize();
        auto p = this->getPosition();
        setPos(m_key.c_str(), p.x / win.width, p.y / win.height);
        Notification::create()
            ->setTitle("Frame Windows")
            ->setText(fmt::format("{} сохранён ({:.2f}, {:.2f})", m_key, p.x / win.width, p.y / win.height))
            ->setIcon(NotificationIcon::Info)
            ->post();
    }
    void registerTouch() {
        cocos2d::CCTouchDispatcher::get()->registerForcePrio(this, 2);
    }
};

// --- Статичный HUD: FPS + мс ------------------------------------------------
class StatusHud : public DragLayer {
public:
    cocos2d::CCLabelBMFont* m_fps = nullptr;
    cocos2d::CCLabelBMFont* m_ms  = nullptr;
    static StatusHud* create() {
        auto ret = new StatusHud();
        if (ret->init()) { ret->autorelease(); return ret; }
        delete ret; return nullptr;
    }
    bool init() override {
        if (!DragLayer::init("status")) return false;
        float scale = Mod::get()->getSettingValue<double>("status-scale");
        m_fps = cocos2d::CCLabelBMFont::create("FPS: -", "bigFont.fnt");
        m_ms  = cocos2d::CCLabelBMFont::create("-- мс", "bigFont.fnt");
        this->addChild(m_fps); this->addChild(m_ms);
        m_ms->setPositionY(-24);
        this->setScale(scale);
        auto p = getPos("status");
        auto win = cocos2d::CCDirector::sharedDirector()->getWinSize();
        this->setPosition({p.x * win.width, p.y * win.height});
        this->setContentSize({200, 60});
        this->setupFrame({200, 60});
        this->registerTouch();
        this->schedule(schedule_selector(StatusHud::tick));
        return true;
    }
    void tick(float) {
        if (!g_state.hudHasValue || !g_state.visible) {
            m_fps->setString(g_state.visible ? "FPS: -" : "");
            m_ms->setString(g_state.visible ? "-- мс" : "");
            return;
        }
        m_fps->setString(fmt::format("FPS: {:.1f}", g_state.lastPerfectFps));
        m_ms->setString(fmt::format("{:.1f} мс", g_state.lastMsWindow));
    }
};

// --- Счётчик окон ------------------------------------------------------------
class CounterHud : public DragLayer {
public:
    std::vector<cocos2d::CCLabelBMFont*> m_lines;
    static CounterHud* create() {
        auto ret = new CounterHud();
        if (ret->init()) { ret->autorelease(); return ret; }
        delete ret; return nullptr;
    }
    bool init() override {
        if (!DragLayer::init("counter")) return false;
        auto title = cocos2d::CCLabelBMFont::create("Окна кликов", "goldFont.fnt");
        this->addChild(title);
        title->setPositionY(20);
        for (int i = 0; i < 8; ++i) {
            auto l = cocos2d::CCLabelBMFont::create("", "bigFont.fnt");
            this->addChild(l);
            l->setPositionY(20 - (i + 1) * 20);
            m_lines.push_back(l);
        }
        auto p = getPos("counter");
        auto win = cocos2d::CCDirector::sharedDirector()->getWinSize();
        this->setPosition({p.x * win.width, p.y * win.height});
        this->setContentSize({220, 190});
        this->setupFrame({220, 190});
        this->registerTouch();
        this->schedule(schedule_selector(CounterHud::tick));
        return true;
    }
    static ccColor3B bucketColor(float frames) { return colorFor(frames); }
    void tick(float) {
        if (!g_state.visible || !Mod::get()->getSettingValue<bool>("counter-enabled")) {
            for (auto* l : m_lines) l->setString("");
            return;
        }
        auto& src = Mod::get()->getSettingValue<std::string>("counter-sources");
        int line = 0;
        for (size_t i = 0; i < s_buckets.size() && line < 8; ++i, ++line) {
            auto [lo, hi] = s_buckets[i];
            int n = g_state.windowBuckets.count(i) ? g_state.windowBuckets[i] : 0;
            auto col = bucketColor(lo);
            char buf[64];
            if (hi > 1e8) snprintf(buf, 64, "%.1f+: %d", lo, n);
            else          snprintf(buf, 64, "%.1f-%.1f: %d", lo, hi, n);
            m_lines[line]->setString(buf);
            m_lines[line]->setColor(col);
        }
        for (; line < 8; ++line) m_lines[line]->setString("");
    }
};

// ---------------------------------------------------------------------------
// Кружок в стиле FB frame counter: ТОЛЬКО толстая обводка, внутри пусто,
// число кадров по центру. Плюсы — под кружком.
// ---------------------------------------------------------------------------
class ClickMarker : public cocos2d::CCNode {
public:
    static ClickMarker* create(float frames, bool isRelease, int pluses, bool preview) {
        auto ret = new ClickMarker();
        if (ret->init(frames, isRelease, pluses, preview)) { ret->autorelease(); return ret; }
        delete ret; return nullptr;
    }
    bool init(float frames, bool isRelease, int pluses, bool preview) {
        if (!CCNode::init()) return false;
        float outline = Mod::get()->getSettingValue<double>("marker-outline-width");
        float r = preview ? 26.f : 22.f;
        auto col = colorFor(frames);
        // обводка: два круга — внешний цвета и внутренний «дырка»
        auto outer = cocos2d::CCDrawNode::create();
        outer->drawCircle({0, 0}, r, col, 255, 100, col, nullptr);
        this->addChild(outer);
        // сам «контур» рисуется толстым штрихом:
        auto ring = cocos2d::CCDrawNode::create();
        ring->drawCircle({0,0}, r, col, 255, outline, col, nullptr);
        this->addChild(ring);
        if (isRelease) ring->setOpacity(160); // отжатие — приглушённый тон
        // число кадров
        char buf[24];
        if (frames <= 0.f) snprintf(buf, 24, "0");
        else snprintf(buf, 24, "%.3f", frames);
        auto label = cocos2d::CCLabelBMFont::create(buf, "bigFont.fnt");
        label->setScale(0.35f);
        label->setColor(col);
        this->addChild(label);
        // плюсы
        if (pluses > 0) {
            int shown = Mod::get()->getSettingValue<int64_t>("max-pluses");
            std::string plus = pluses <= shown
                ? std::string(pluses, '+')
                : fmt::format("+{}", pluses);
            auto p = cocos2d::CCLabelBMFont::create(plus.c_str(), "bigFont.fnt");
            p->setScale(0.3f);
            p->setColor(col);
            p->setPositionY(-r - 12);
            this->addChild(p);
        }
        // появление: быстрый scale-in, затем плавное затухание
        float life = Mod::get()->getSettingValue<double>("popup-lifetime");
        this->setScale(0.2f);
        this->runAction(cocos2d::CCEaseOut::create(cocos2d::CCScaleTo::create(0.08f, 1.f), 2.f));
        this->runAction(cocos2d::CCSequence::create(
            cocos2d::CCDelayTime::create(life * 0.6f),
            cocos2d::CCFadeOut::create(life * 0.4f),
            cocos2d::CCRemoveSelf::create(),
            nullptr));
        return true;
    }
};

// ---------------------------------------------------------------------------
// Слой-контейнер поверх игры: держит HUD-элементы и временные кружки
// ---------------------------------------------------------------------------
class FrameWindowsOverlay : public cocos2d::CCLayer {
public:
    StatusHud* m_status = nullptr;
    CounterHud* m_counter = nullptr;
    static FrameWindowsOverlay* get() {
        static FrameWindowsOverlay* inst = nullptr;
        if (!inst || !cocos2d::CCScene::get() /* проверка живости */) {
            // создаётся в PlayLayer::init
        }
        return inst;
    }
    static FrameWindowsOverlay* createInto(cocos2d::CCScene* scene) {
        auto ret = new FrameWindowsOverlay();
        if (ret->init()) {
            ret->autorelease();
            scene->addChild(ret, 1000);
            ret->m_status = StatusHud::create();
            ret->addChild(ret->m_status);
            ret->m_counter = CounterHud::create();
            ret->addChild(ret->m_counter);
            return ret;
        }
        delete ret; return nullptr;
    }
    void spawnMarker(const cocos2d::CCPoint& pos, float frames, bool isRelease, int pluses) {
        if (!Mod::get()->getSettingValue<bool>("markers-enabled")) return;
        if (isRelease && !Mod::get()->getSettingValue<bool>("release-markers")) return;
        auto m = ClickMarker::create(frames, isRelease, pluses, false);
        m->setPosition(this->convertToNodeSpace(pos));
        this->addChild(m);
    }
};

// ---------------------------------------------------------------------------
// Хуки: подсчёт кадров и событий
// ---------------------------------------------------------------------------
static double s_lastTickTime = 0.0;
static double s_frameDurationMs = 16.667; // фактическая длительность последнего кадра
static int    s_physFrame = 0;            // номер тика физики (для дробных окон CBF)
static int    s_cbfDelay = 0;

// --- нажатие -----------------------------------------------------------------
class $modify(PlayerHook, PlayerObject) {
    void pushButton(PlayerButton p) {
        PlayerHook::pushButton(p);
        if (!g_state.visible || g_state.dragMode) return;
        auto pl = PlayLayer::get();
        if (!pl) return;

        double now = cocos2d::utils::getTimeMs();
        // смещение клика от последнего тика кадра -> доля кадра
        float frac = std::fmod(now, s_frameDurationMs) / s_frameDurationMs;
        float windowFrames = computeWindow(frac);
        g_state.pressesThisFrame++;
        int pluses = g_state.pressesThisFrame - 1;

        float fpsPerfect = 1000.f / std::max(1e-3f, frac * s_frameDurationMs);
        g_state.lastPerfectFps = fpsPerfect;
        g_state.lastMsWindow = windowFrames * s_frameDurationMs;
        g_state.hudHasValue = true;

        // счётчик: клик попадает в первый подходящий промежуток (min <= x < max)
        int bucket = bucketFor(windowFrames);
        if (bucket >= 0) g_state.windowBuckets[bucket]++;
        g_state.totalClicks++;

        auto scene = cocos2d::CCDirector::sharedDirector()->getRunningScene();
        if (auto ov = static_cast<FrameWindowsOverlay*>(scene->getChildByTag(1000)))
            ov->spawnMarker(pl->getPlayerPosition(), windowFrames, false, pluses);

        playSound("press", windowFrames);
    }
    void releaseButton(PlayerButton p) {
        PlayerHook::releaseButton(p);
        if (!g_state.visible || g_state.dragMode) return;
        auto pl = PlayLayer::get();
        if (!pl) return;
        double now = cocos2d::utils::getTimeMs();
        float frac = std::fmod(now, s_frameDurationMs) / s_frameDurationMs;
        float windowFrames = computeWindow(frac);
        auto scene = cocos2d::CCDirector::sharedDirector()->getRunningScene();
        if (auto ov = static_cast<FrameWindowsOverlay*>(scene->getChildByTag(1000)))
            ov->spawnMarker(pl->getPlayerPosition(), windowFrames, true, 0); // плюсы у отжатий убраны (2.0)
        playSound("release", windowFrames);
    }
};

static float computeWindow(float frac) {
    // базовое окно из превью-сканирования уровня + поправка на смещение клика
    // в кадре: чем ближе к тику, тем больше реального времени остаётся.
    // Здесь — рабочий расчёт на базе текущего FPS и позиции игрока.
    float base = PreviewCache::currentWindowFrames(); // из сканера уровня
    float shift = 1.f - frac;                          // остаток кадра
    return base * shift;                               // честно для CBF: дробные кадры внутри base
}

static int bucketFor(float frames) {
    for (size_t i = 0; i < s_buckets.size(); ++i)
        if (frames >= s_buckets[i].first && frames < s_buckets[i].second) return i;
    return -1;
}

static void playSound(const char* section, float frames) {
    bool on = Mod::get()->getSettingValue<bool>("sounds-enabled");
    if (strcmp(section, "release") == 0 && !Mod::get()->getSettingValue<bool>("release-sounds-enabled")) on = false;
    if (!on) return;
    // правила читаются из frame-sounds.json один раз при старте уровня
    for (auto& rule : SoundRules::get(section)) {
        if (frames >= rule.minFrames && frames < rule.maxFrames) {
            FMODAudioEngine::sharedEngine()->playEffect(rule.file.c_str(), false, rule.volume, 0, 1);
            return;
        }
    }
}

// --- кадр: сброс плюсов --------------------------------------------------------
class $modify(DirectorHook, cocos2d::CCDirector) {
    void drawScene() {
        DirectorHook::drawScene();
        // конец frame window: снимаем старые плюсы (их срок жизни — кадр)
        // и пересчитываем длительность кадра для точного замера
        double now = cocos2d::utils::getTimeMs();
        if (s_lastTickTime > 0) s_frameDurationMs = std::clamp(now - s_lastTickTime, 1.0, 200.0);
        s_lastTickTime = now;
        g_state.pressesThisFrame = 0;
    }
};

// --- перезапуск уровня ---------------------------------------------------------
class $modify(PlayLayerHook, PlayLayer) {
    bool init(GJBaseGameLayer* p0, int p1, bool p2, bool p3) {
        if (!PlayLayerHook::init(p0, p1, p2, p3)) return false;
        loadHudJson();
        g_state = FrameWindowsState{};
        auto scene = cocos2d::CCDirector::sharedDirector()->getRunningScene();
        if (scene) {
            if (auto old = scene->getChildByTag(1000)) old->removeFromParent();
            if (auto ov = FrameWindowsOverlay::createInto(scene)) ov->setTag(1000);
        }
        SoundRules::reload();
        PreviewCache::scanLevel(this);
        return true;
    }
    void resetLevel() {
        PlayLayerHook::resetLevel();
        g_state.windowBuckets.clear();
        g_state.totalClicks = 0;
    }
};

// --- хоткеи: TAB (тумблер), F9 (drag-режим) -------------------------------------
class $modify(KeyHook, cocos2d::CCLayer) {
    void keyBackClicked() {}
};

// Регистрация клавиш через Geode keybinds (упрощённо):
static void initKeybinds() {
    // TAB: g_state.visible = !g_state.visible;
    // F9:  g_state.dragMode = !g_state.dragMode; курсор активен, клики игры игнорируются
}

$on_mod(Loaded) {
    loadHudJson();
    initKeybinds();
}
