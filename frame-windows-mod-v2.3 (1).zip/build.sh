#!/usr/bin/env bash
command -v geode >/dev/null || { echo "[!] Install Geode CLI: https://github.com/geode-sdk/cli/releases"; exit 1; }
if [ -z "$GEODE_SDK" ]; then geode sdk install nightly --ready && geode sdk setup; fi
geode build
